<?php
// includes/functions.php

function seoTitle($title) {
    $title = strtolower(trim($title));
    $find = ['ç','ğ','ı','ö','ş','ü',' '];
    $replace = ['c','g','i','o','s','u','-'];
    $title = str_replace($find, $replace, $title);
    $title = preg_replace('/[^a-z0-9\-]/', '', $title);
    $title = preg_replace('/-+/', '-', $title);
    return $title;
}

function limitText($text, $limit = 150) {
    if(strlen($text) > $limit) {
        $text = substr($text, 0, $limit) . '...';
    }
    return $text;
}
?>
<?php
// includes/footer.php
?>
</main>
<footer>
    <div class="container footer-menu">
        <ul>
            <li><a href="hakkimizda.php">Hakkımızda</a></li>
            <li><a href="gizlilik.php">Gizlilik Politikası</a></li>
            <li><a href="kullanimsartlari.php">Kullanım Şartları</a></li>
            <li><a href="iletisim.php">İletişim</a></li>
            <li><a href="rss.php">RSS</a></li>
            <li><a href="sitemap.php">Site Haritası</a></li>
        </ul>
    </div>
    <div class="container copyright">
        &copy; <?= date('Y') ?> HaberSite. Tüm hakları saklıdır.
    </div>
</footer>
</body>
</html>
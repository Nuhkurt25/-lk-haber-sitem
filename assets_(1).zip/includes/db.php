<?php
// includes/db.php
$host = 'localhost';
$db   = 'blackxna_nuh';
$user = 'blackxna_nuh';
$pass = 'AGhm1453.';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("Veritabanı bağlantısı kurulamadı: " . $e->getMessage());
}
?>
<?php
// includes/header.php
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Haber Sitesi' ?></title>
    <meta name="description" content="<?= isset($pageDescription) ? htmlspecialchars($pageDescription) : 'Güncel haberler, son dakika, video galeri ve daha fazlası.' ?>" />
    <meta name="keywords" content="haber, son dakika, video, galeri, güncel, Türkiye" />
    
    <!-- Google News ve SEO için temel meta -->
    <link rel="canonical" href="<?= 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] ?>" />
    <meta name="robots" content="index, follow" />

    <!-- Google Analytics (örnek) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-XXXXXXX-X"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'UA-XXXXXXX-X');
    </script>

    <!-- Google Adsense (örnek) -->
    <script data-ad-client="ca-pub-XXXXXXXXXXXXXX" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
<header>
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="logo">HaberSite</a>
            <ul class="menu">
                <li><a href="index.php">Ana Sayfa</a></li>
                <li><a href="hakkimizda.php">Hakkımızda</a></li>
                <li><a href="gizlilik.php">Gizlilik</a></li>
                <li><a href="kullanimsartlari.php">Kullanım Şartları</a></li>
                <li><a href="iletisim.php">İletişim</a></li>
                <li><a href="rss.php">RSS</a></li>
                <li><a href="sitemap.php">Site Haritası</a></li>
                <li><a href="arama.php">Ara</a></li>
            </ul>
            <div class="menu-toggle" id="mobile-menu">☰</div>
        </div>
    </nav>
</header>
<script>
    const menuToggle = document.getElementById('mobile-menu');
    const menu = document.querySelector('.menu');
    menuToggle.addEventListener('click', () => {
        menu.classList.toggle('active');
    });
</script>
<main>
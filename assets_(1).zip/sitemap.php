<?php
// sitemap.php
header('Content-Type: application/xml; charset=utf-8');
require_once 'includes/db.php';

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>

<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

    <url>
        <loc>https://<?= $_SERVER['HTTP_HOST'] ?>/index.php</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>

    <?php
    // Kategoriler
    $kategoriler = $pdo->query("SELECT * FROM kategoriler")->fetchAll(PDO::FETCH_ASSOC);
    foreach($kategoriler as $kategori): ?>
    <url>
        <loc>https://<?= $_SERVER['HTTP_HOST'] ?>/kategori.php?id=<?= $kategori['id'] ?></loc>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>
    <?php endforeach; ?>

    <?php
    // Haberler
    $haberler = $pdo->query("SELECT * FROM haberler")->fetchAll(PDO::FETCH_ASSOC);
    foreach($haberler as $haber): ?>
    <url>
        <loc>https://<?= $_SERVER['HTTP_HOST'] ?>/haber.php?id=<?= $haber['id'] ?></loc>
        <lastmod><?= date('Y-m-d', strtotime($haber['yayin_tarihi'])) ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.9</priority>
    </url>
    <?php endforeach; ?>

</urlset>
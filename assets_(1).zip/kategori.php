<?php
// kategori.php
require_once 'includes/db.php';
require_once 'includes/functions.php';

// URL'den kategori ID al
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id) {
    header("Location: index.php");
    exit;
}

// Kategori bilgisi al
$stmt = $pdo->prepare("SELECT * FROM kategoriler WHERE id = :id");
$stmt->execute([':id' => $id]);
$kategori = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$kategori) {
    header("Location: index.php");
    exit;
}

$pageTitle = htmlspecialchars($kategori['isim']) . " Haberleri";
$pageDescription = $kategori['isim'] . " kategorisindeki güncel haberler.";

include 'includes/header.php';

// Kategoriye ait haberleri çek
function getHaberler($pdo, $filter = []) {
    $sql = "SELECT h.*, k.isim as kategori FROM haberler h 
            JOIN kategoriler k ON h.kategori_id = k.id ";
    $where = [];
    $params = [];

    if(isset($filter['kategori_id'])) {
        $where[] = "h.kategori_id = :kategori_id";
        $params[':kategori_id'] = $filter['kategori_id'];
    }

    if($where) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }

    if(isset($filter['order'])) {
        $sql .= " ORDER BY " . $filter['order'];
    } else {
        $sql .= " ORDER BY h.yayin_tarihi DESC";
    }

    if(isset($filter['limit'])) {
        $sql .= " LIMIT " . intval($filter['limit']);
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$haberler = getHaberler($pdo, ['kategori_id' => $id, 'order' => 'yayin_tarihi DESC']);
?>

<div class="container">
    <h1><?= htmlspecialchars($kategori['isim']) ?> Haberleri</h1>
    <?php if(count($haberler) == 0): ?>
        <p>Bu kategoride henüz haber bulunmamaktadır.</p>
    <?php else: ?>
        <?php foreach($haberler as $haber): ?>
            <article class="haber-kutusu">
                <?php if($haber['resim']): ?>
                    <img src="uploads/<?= htmlspecialchars($haber['resim']) ?>" alt="<?= htmlspecialchars($haber['baslik']) ?>" />
                <?php endif; ?>
                <div class="icerik">
                    <h3><a href="haber.php?id=<?= $haber['id'] ?>"><?= htmlspecialchars($haber['baslik']) ?></a></h3>
                    <p><?= limitText(strip_tags($haber['ozet'] ?: $haber['icerik']), 150) ?></p>
                    <small>Yayın Tarihi: <?= date('d.m.Y H:i', strtotime($haber['yayin_tarihi'])) ?></small>
                </div>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
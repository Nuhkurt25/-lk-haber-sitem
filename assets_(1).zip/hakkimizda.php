<?php
// hakkimizda.php
$pageTitle = "Hakkımızda";
$pageDescription = "Hakkımızda sayfası";

include 'includes/header.php';
?>

<div class="container">
    <h1>Hakkımızda</h1>
    <p>Buraya site hakkında detaylı bilgi yazabilirsiniz.</p>
</div>

<?php include 'includes/footer.php'; ?>
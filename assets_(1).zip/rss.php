<?php
// rss.php
header("Content-Type: application/rss+xml; charset=UTF-8");
require_once 'includes/db.php';

echo '<?xml version="1.0" encoding="UTF-8" ?>';
?>

<rss version="2.0">
<channel>
    <title>HaberSite - Güncel Haberler</title>
    <link>https://<?= $_SERVER['HTTP_HOST'] ?>/</link>
    <description>Türkiye ve dünya gündeminden son dakika haberleri.</description>
    <language>tr-tr</language>
    <lastBuildDate><?= date(DATE_RSS) ?></lastBuildDate>

    <?php
    $haberler = $pdo->query("SELECT * FROM haberler ORDER BY yayin_tarihi DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($haberler as $haber): 
        $link = "https://" . $_SERVER['HTTP_HOST'] . "/haber.php?id=" . $haber['id'];
    ?>
    <item>
        <title><?= htmlspecialchars($haber['baslik']) ?></title>
        <link><?= $link ?></link>
        <description><![CDATA[<?= $haber['ozet'] ?: substr(strip_tags($haber['icerik']), 0, 200) ?>]]></description>
        <pubDate><?= date(DATE_RSS, strtotime($haber['yayin_tarihi'])) ?></pubDate>
        <guid><?= $link ?></guid>
    </item>
    <?php endforeach; ?>

</channel>
</rss>
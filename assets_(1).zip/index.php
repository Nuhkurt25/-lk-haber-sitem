<?php
// index.php

$pageTitle = "Haber Sitesi - Güncel Haberler ve Son Dakika";
$pageDescription = "Türkiye ve dünya gündeminden son dakika haberleri, video galeri, foto galeri ve daha fazlası.";

require_once 'includes/db.php';
require_once 'includes/functions.php';
include 'includes/header.php';

// Son dakika haberleri (son_dakika=1)
$sonDakikaHaberler = getHaberler($pdo, ['son_dakika' => 1, 'order' => 'yayin_tarihi DESC', 'limit' => 5]);

// Manşet haberler (manseet=1)
$manşetHaberler = getHaberler($pdo, ['manseet' => 1, 'order' => 'yayin_tarihi DESC', 'limit' => 5]);

// Tüm kategoriler
$kategoriler = $pdo->query("SELECT * FROM kategoriler ORDER BY isim ASC")->fetchAll(PDO::FETCH_ASSOC);

// En çok okunan 5 haber
$enCokOkunan = getHaberler($pdo, ['order' => 'goruntulenme DESC', 'limit' => 5]);

// Banner alanı için örnek (istersen ekleyebilirsin)
?>

<div class="container">

    <section class="son-dakika">
        <marquee behavior="scroll" direction="left" scrollamount="6">
            <?php foreach($sonDakikaHaberler as $haber): ?>
                <?= htmlspecialchars($haber['baslik']) ?> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
            <?php endforeach; ?>
        </marquee>
    </section>

    <section class="manşet">
        <h2>Manşet Haberler</h2>
        <div class="manset-container">
            <?php foreach($manşetHaberler as $haber): ?>
                <article class="haber-kutusu">
                    <?php if($haber['resim']): ?>
                        <img src="uploads/<?= htmlspecialchars($haber['resim']) ?>" alt="<?= htmlspecialchars($haber['baslik']) ?>" />
                    <?php endif; ?>
                    <div class="icerik">
                        <h3><a href="haber.php?id=<?= $haber['id'] ?>"><?= htmlspecialchars($haber['baslik']) ?></a></h3>
                        <p><?= limitText(strip_tags($haber['ozet'] ?: $haber['icerik']), 120) ?></p>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="kategori-haberler">
        <?php foreach($kategoriler as $kategori): 
            $haberler = getHaberler($pdo, ['kategori_id' => $kategori['id'], 'limit' => 5]);
        ?>
        <h2><?= htmlspecialchars($kategori['isim']) ?></h2>
        <div class="kategori-container">
            <?php foreach($haberler as $haber): ?>
                <article class="haber-kutusu">
                    <?php if($haber['resim']): ?>
                        <img src="uploads/<?= htmlspecialchars($haber['resim']) ?>" alt="<?= htmlspecialchars($haber['baslik']) ?>" />
                    <?php endif; ?>
                    <div class="icerik">
                        <h3><a href="haber.php?id=<?= $haber['id'] ?>"><?= htmlspecialchars($haber['baslik']) ?></a></h3>
                        <p><?= limitText(strip_tags($haber['ozet'] ?: $haber['icerik']), 100) ?></p>
                    </div>
                </article>
            <?php endforeach; ?>
            <a href="kategori.php?id=<?= $kategori['id'] ?>">Tümünü Görüntüle &raquo;</a>
        </div>
        <?php endforeach; ?>
    </section>

    <section class="en-cok-okunan">
        <h2>En Çok Okunan Haberler</h2>
        <ul>
            <?php foreach($enCokOkunan as $haber): ?>
                <li><a href="haber.php?id=<?= $haber['id'] ?>"><?= htmlspecialchars($haber['baslik']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    </section>

</div>

<?php
include 'includes/footer.php';

// Haber çekme fonksiyonu
function getHaberler($pdo, $filter = []) {
    $sql = "SELECT h.*, k.isim as kategori FROM haberler h 
            JOIN kategoriler k ON h.kategori_id = k.id ";
    $where = [];
    $params = [];

    if(isset($filter['manseet']) && $filter['manseet']) {
        $where[] = "h.manseet = 1";
    }
    if(isset($filter['son_dakika']) && $filter['son_dakika']) {
        $where[] = "h.son_dakika = 1";
    }
    if(isset($filter['kategori_id'])) {
        $where[] = "h.kategori_id = :kategori_id";
        $params[':kategori_id'] = $filter['kategori_id'];
    }

    if($where) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }

    if(isset($filter['order'])) {
        $sql .= " ORDER BY " . $filter['order'];
    } else {
        $sql .= " ORDER BY h.yayin_tarihi DESC";
    }

    if(isset($filter['limit'])) {
        $sql .= " LIMIT " . intval($filter['limit']);
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
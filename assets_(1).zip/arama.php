<?php
// arama.php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$pageTitle = $q ? "Arama Sonuçları: " . htmlspecialchars($q) : "Arama";

include 'includes/header.php';

$haberler = [];
if($q) {
    $stmt = $pdo->prepare("SELECT h.*, k.isim as kategori FROM haberler h 
                           JOIN kategoriler k ON h.kategori_id = k.id
                           WHERE h.baslik LIKE :q OR h.icerik LIKE :q
                           ORDER BY h.yayin_tarihi DESC");
    $stmt->execute([':q' => "%$q%"]);
    $haberler = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container">
    <h1>Arama</h1>
    <form method="GET" action="arama.php">
        <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Haber ara..." required />
        <button type="submit">Ara</button>
    </form>

    <?php if($q): ?>
        <h2>"<?= htmlspecialchars($q) ?>" için <?= count($haberler) ?> sonuç bulundu.</h2>
        <?php if(count($haberler) == 0): ?>
            <p>Sonuç bulunamadı.</p>
        <?php else: ?>
            <?php foreach($haberler as $haber): ?>
                <article class="haber-kutusu">
                    <?php if($haber['resim']): ?>
                        <img src="uploads/<?= htmlspecialchars($haber['resim']) ?>" alt="<?= htmlspecialchars($haber['baslik']) ?>" />
                    <?php endif; ?>
                    <div class="icerik">
                        <h3><a href="haber.php?id=<?= $haber['id'] ?>"><?= htmlspecialchars($haber['baslik']) ?></a></h3>
                        <p><?= limitText(strip_tags($haber['ozet'] ?: $haber['icerik']), 150) ?></p>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
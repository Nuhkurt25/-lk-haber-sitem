<?php
// haber.php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id) {
    header("Location: index.php");
    exit;
}

// Haber çek
$stmt = $pdo->prepare("SELECT h.*, k.isim as kategori FROM haberler h 
                       JOIN kategoriler k ON h.kategori_id = k.id 
                       WHERE h.id = :id");
$stmt->execute([':id' => $id]);
$haber = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$haber) {
    header("Location: index.php");
    exit;
}

// Görüntülenme sayısını artır
$pdo->prepare("UPDATE haberler SET goruntulenme = goruntulenme + 1 WHERE id = :id")
    ->execute([':id' => $id]);

$pageTitle = htmlspecialchars($haber['baslik']);
$pageDescription = limitText(strip_tags($haber['ozet'] ?: $haber['icerik']), 160);

include 'includes/header.php';
?>

<div class="container">
    <article class="haber-detay">
        <h1><?= htmlspecialchars($haber['baslik']) ?></h1>
        <p><small>Kategori: <a href="kategori.php?id=<?= $haber['kategori_id'] ?>"><?= htmlspecialchars($haber['kategori']) ?></a> | Yayın Tarihi: <?= date('d.m.Y H:i', strtotime($haber['yayin_tarihi'])) ?></small></p>

        <?php if($haber['resim']): ?>
            <img src="uploads/<?= htmlspecialchars($haber['resim']) ?>" alt="<?= htmlspecialchars($haber['baslik']) ?>" style="max-width:100%; border-radius:6px; margin-bottom:20px;" />
        <?php endif; ?>

        <?php if($haber['video_link']): ?>
            <div class="video-container" style="margin-bottom:20px;">
                <iframe width="100%" height="400" src="<?= htmlspecialchars($haber['video_link']) ?>" frameborder="0" allowfullscreen></iframe>
            </div>
        <?php endif; ?>

        <div class="icerik-text">
            <?= nl2br($haber['icerik']) ?>
        </div>
    </article>
</div>

<?php include 'includes/footer.php'; ?>